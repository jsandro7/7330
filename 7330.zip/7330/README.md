<h2>Prequisite:</h2>
MySQL 8 server : <a href="https://dev.mysql.com/downloads/mysql/8.0.html">https://dev.mysql.com/downloads/mysql/8.0.html</a>
<br />

Connect to the MySql instance and run the next two script in order specified below:<br />

<ul>
<li>
 dbCreate.sql
 </li> 
 <li> populateTable.sql 
 </li>
 </ul>

<p>
Python packages needed:

<ul>
<li>
nicegui
</li>
<li>
mysqlclient
</li>
</ul>
</p>

<h2>
Running App
</h2>

python Main.py