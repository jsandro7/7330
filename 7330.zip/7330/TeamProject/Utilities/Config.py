mysql = {
    "host": "localhost",
    "user": "7330Team",
    "password": "Smu-Team2024!",
    "db": "degrees",
}