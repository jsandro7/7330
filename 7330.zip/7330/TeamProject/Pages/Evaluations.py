from nicegui import ui

from TeamProject.Pages.Instructor import get_instructor
from TeamProject.Utilities import MySql, Validation

def get_data():
    conn = MySql.create_conn()
    cursor = conn.cursor(dictionary=True)

    stmt = """
    SELECT
        section_id,
        code,
        evaluation_method,
        comment,
        A_count,
        B_count,
        C_count,
        F_count
    FROM evaluation    
    """
    cursor.execute(stmt)
    rows = cursor.fetchall()

    conn.close()
    return rows

def get_filtered_sections(instructor_id, semester):
    """
    Retrieves sections taught by a specific instructor during a given semester and year.
    """
    conn = MySql.create_conn()
    cursor = conn.cursor(dictionary=True)

    stmt = """
    SELECT 
        s.section_id,
        s.course_id,
        c.name AS course_name,
        s.student_enrolled
    FROM 
        section s
    JOIN 
        course c ON s.course_id = c.course_id
    WHERE 
        s.ID = %s AND s.semester = %s 
    ORDER BY 
        s.section_id
    """
    cursor.execute(stmt, (instructor_id, semester))
    rows = cursor.fetchall()

    conn.close()
    return rows

def update_evaluation(section_id, field, new_value):
    """
    Update the evaluation record in the database.
    """
    conn = MySql.create_conn()
    cursor = conn.cursor()

    # Construct the update query dynamically based on the edited field
    stmt = f"""
    UPDATE evaluation
    SET {field} = %s
    WHERE section_id = %s
    """
    try:
        cursor.execute(stmt, (new_value, section_id))
        conn.commit()
        print(f"Updated {field} to {new_value} for section_id {section_id}")
    except Exception as e:
        print(f"Failed to update evaluation: {e}")
    finally:
        conn.close()

def get_section_info(section_id):
    conn = MySql.create_conn()
    cursor = conn.cursor(dictionary=True)
    stmt = """
    SELECT 
        e.section_id,
        e.code,
        e.evaluation_method,
        e.comment,
        e.A_count,
        e.B_count,
        e.C_count, 
        e.F_count
    FROM 
        evaluation e
    WHERE 
        e.section_id = %s 
    ORDER BY 
        e.section_id
    """
    # Wrap section_id in a tuple
    cursor.execute(stmt, (section_id,))
    rows = cursor.fetchall()
    return rows

def page():
    rows = get_data()

    instructors = get_instructor()
    instructors_options = {
        instructor["ID"]: f"{instructor['name']}"
        for instructor in instructors
    }

    columns = [
        {'name': 'section_id', 'field': 'section_id', 'label': 'Section', 'editable': False},
        {'name': 'course_id', 'field': 'course_id', 'label': 'Course ID', 'editable': False},
        {'name': 'course_name', 'field': 'course_name', 'label': 'Course Name', 'editable': False},
        {'name': 'student_enrolled', 'field': 'student_enrolled', 'label': 'Students Enrolled', 'editable': False},
    ]

    eval_columns = [
        {'name': 'section_id', 'field': 'section_id', 'label': 'Section Id', 'editable': False},
        {'name': 'code', 'field': 'code', 'label': 'Code', 'editable': False},
        {'name': 'evaluation_method', 'field': 'evaluation_method', 'label': 'Course Name', 'editable': True},
        {'name': 'A_count', 'field': 'A_count', 'label': 'A_count', 'editable': True},
        {'name': 'B_count', 'field': 'B_count', 'label': 'B_count', 'editable': True},
        {'name': 'C_count', 'field': 'C_count', 'label': 'C_count', 'editable': True},
        {'name': 'F_count', 'field': 'F_count', 'label': 'F_count', 'editable': True},

    ]

    filtered_rows = []
    eval_rows = []
    async def filter_sections():
        """
        Filters sections based on the selected instructor, semester, and year.
        """
        if not instructor_input.value or not semester_input.value:
            ui.notify("All fields are required!", color="negative")
            return

        nonlocal filtered_rows
        filtered_rows = get_filtered_sections(
            instructor_id=instructor_input.value,
            semester=semester_input.value
        )

        # Update the table with filtered rows
        aggrid.options['rowData'] = filtered_rows
        aggrid.update()

    def on_cell_value_changed(event):
        """
        Handle cell value changes and update the server.
        """
        # Extract relevant information from the event
        updated_data = event.args.get('data')  # Full row data
        updated_value = event.args.get('value')  # New value for the cell
        print(updated_value)
        field = event.args.get('colId')  # Column ID of the edited cell
        print(field)
        col_def = event.args.get('colDef')  # Get colDef, if present
        # print(col_def)
        # Safely extract column name

        if updated_data and updated_value is not None:
            section_id = updated_data['section_id']  # Extract the primary key

            # Print column name and new value
            # print(f"Column Name: {column_name}, Field: {field}, New Value: {updated_value}, Section ID: {section_id}")

            # Update the server with the new value
            print(updated_value)
            print(field)
            update_evaluation(section_id, field, updated_value)


    def on_cell_click(event):
        """
        Event handler for cell clicks. Prints the section_id of the clicked cell.
        """
        if event.args and "data" in event.args and "section_id" in event.args["data"]:
            section_id = event.args["data"]["section_id"]
            print(f"Section ID: {section_id}")
            eval_rows = get_section_info(section_id)
            eval_aggrid.options['rowData'] = eval_rows
            eval_aggrid.update()

            ui.notify(f"Clicked Section ID: {section_id}")
        else:
            ui.notify("Invalid cell clicked.", color="negative")

    with ui.row().classes("items-left"):
        instructor_input = ui.select(instructors_options, label="Instructor").classes("w-48")
        semester_input = ui.select(["SP", "SM", "FA"], label="Semester").classes("w-48")

        ui.button("Filter Sections", on_click=filter_sections)

    aggrid = ui.aggrid({
        'columnDefs': columns,
        'rowData': rows,
        'rowSelection': 'multiple',
        'stopEditingWhenCellsLoseFocus': True,
    }).on('cellClicked', on_cell_click)



    eval_aggrid = ui.aggrid({
        'columnDefs': eval_columns,
        'rowData': eval_rows,
        'rowSelection': 'multiple',
        'stopEditingWhenCellsLoseFocus': True,
    }).on('cellClicked', on_cell_value_changed)













